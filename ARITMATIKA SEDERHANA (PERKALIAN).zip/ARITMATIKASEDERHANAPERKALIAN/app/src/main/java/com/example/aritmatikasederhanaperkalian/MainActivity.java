package com.example.aritmatikasederhanaperkalian;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
   private EditText num1;
    private EditText num2;
    private TextView result;
    private Button hitung;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        num1 = (EditText) findViewById(R.id.editNUM1);
        num2 = (EditText) findViewById(R.id.editNUM2);
        result = (TextView) findViewById(R.id.result);
        hitung = (Button) findViewById(R.id.btnHitung);

        hitung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int number1 = Integer.parseInt(num1.getText().toString());
                int number2 = Integer.parseInt(num2.getText().toString());
                int hasil = number1 *number2;
                result.setText(" " + String.valueOf(hasil));
            }
        });

    }
}